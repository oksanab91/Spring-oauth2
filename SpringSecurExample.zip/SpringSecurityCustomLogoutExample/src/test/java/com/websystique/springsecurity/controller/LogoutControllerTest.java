/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.websystique.springsecurity.controller;

import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import javax.servlet.Filter;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.FormLoginRequestBuilder;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;

/**
 *
 * @author Oksana
 */
//@SecurityTestExecutionListeners
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@WebAppConfiguration
public class LogoutControllerTest {
    
    
    @Autowired
    private WebApplicationContext context;
    
    @Autowired
    private Filter springSecurityFilterChain;
    
    private MockMvc mvc;
    
//    public LogoutControllerTest() {
//    }
    
//    @BeforeClass
//    public void setUpClass() {
//        
//                
//    }
    
//    @AfterClass
//    public static void tearDownClass() {
//    }
    
    @Before
    public void setUp() {
        mvc = MockMvcBuilders
                .webAppContextSetup(context)
                .addFilters(springSecurityFilterChain)
                .build();
    }

    /**
     * Test of logoutPage method, of class LogoutController.
     * @throws java.lang.Exception
     */
    @Test
    public void testLogoutPage() {
        System.out.println("logoutPage");
//        HttpServletRequest request = null;
//        HttpServletResponse response = null;
//        LogoutController instance = new LogoutController();
//        String expResult = "";
//        String result = instance.logoutPage(request, response);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");

        assertEquals("1", "1");
    }
    
    @Test
    public void authenticationSuccess() throws Exception {
               
//        ResultActions result = mvc.perform(login());
//        System.out.println("test result:");
//        System.out.println(result.toString());
//        

//        mvc
            //.perform(get("/").with(user("admin").password("admin").roles("USER", "ADMIN")));
           
        mvc
            .perform(login())
            .andExpect(authenticated().withUsername("bill"));

        //LOG.info("User with username {} already exist. Nothing will be done. ", user.getUsername());
//        mvc
//            .perform(login())
//            .andExpect(status().isOk());
////            .andExpect(redirectedUrl("/"))
////            .andExpect(authenticated().withUsername("bill"));
    }

    @Test
    public void authenticationFailed() throws Exception {
        //ResultMatcher result = status().isMovedPermanently();
//        mvc
//            .perform(login().user("notfound").password("invalid"))
//            .andExpect(status().isMovedPermanently())
//            .andExpect(redirectedUrl("/login?error"))
//            .andExpect(unauthenticated());
        mvc
            .perform(login().user("notfound").password("invalid"))            
            .andExpect(redirectedUrl("/login?error"))
            .andExpect(unauthenticated());
    }
// loginPage("/login")
    static FormLoginRequestBuilder login() {
        return SecurityMockMvcRequestBuilders
                .formLogin("/login")
                .userParameter("bill")
                .passwordParam("abc123");
    }

//    @Configuration
//    //@EnableWebMvcSecurity
//    @EnableWebMvc
//    static class Config extends WebSecurityConfigurerAdapter {
//
//        @Override
//        protected void configure(HttpSecurity http) throws Exception {
//            http
//                .authorizeRequests()
//                    .anyRequest().authenticated()
//                    .and()
//                .formLogin()
//                    .usernameParameter("bill")
//                    .passwordParameter("abc123")
//                    .loginPage("/login");
//        }
//
//        @Autowired
//        public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//            auth
//                .inMemoryAuthentication()
//                    .withUser("bill").password("abc123").roles("USER");
//            //"bill").password("abc123").roles("USER");
//        }
//    }
    
    
    @Configuration
    @EnableWebSecurity
    @EnableWebMvc
    static class Config extends WebSecurityConfigurerAdapter {

	
	@Autowired
	public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
            //auth.setBeanFactory(beanFactory);
		auth.inMemoryAuthentication().withUser("bill").password("abc123").roles("USER");
//		auth.inMemoryAuthentication().withUser("admin").password("root123").roles("ADMIN");
//		auth.inMemoryAuthentication().withUser("dba").password("root123").roles("ADMIN","DBA");
	}
	
	@Override
	protected void configure(HttpSecurity http)throws Exception {
	  
//	  http.authorizeRequests()
//	  	.antMatchers("/", "/home").permitAll()
//	  	.antMatchers("/admin/**").access("hasRole('ADMIN')")
//	  	.antMatchers("/db/**").access("hasRole('ADMIN') and hasRole('DBA')")
//	  	.and().formLogin().loginPage("/login")
//	  	.usernameParameter("ssoId").passwordParameter("password")
//	  	.and().exceptionHandling().accessDeniedPage("/Access_Denied");
          
            http.authorizeRequests()
	  	.antMatchers("/", "/home").permitAll()
	  	.antMatchers("/admin/**").access("hasRole('ADMIN')")
	  	.antMatchers("/db/**").access("hasRole('ADMIN') and hasRole('DBA')").and()                
                .formLogin().defaultSuccessUrl("/admin").loginPage("/login").permitAll()                
	  	.usernameParameter("bill").passwordParameter("abc123")                
	  	.and().exceptionHandling().accessDeniedPage("/Access_Denied");                
         
	}
    }
    
}
