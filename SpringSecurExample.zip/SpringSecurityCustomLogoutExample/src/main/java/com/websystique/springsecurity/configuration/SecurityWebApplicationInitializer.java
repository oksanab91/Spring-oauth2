package com.websystique.springsecurity.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
//import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;


public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
